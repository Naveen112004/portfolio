Employee Portfolio Website

Files:
- index.html (portfolio homepage)
- employee-attrition.html (project page with outputs)
- optin.html (opt-in landing page to collect emails)

How to use:
1. Download and unzip.
2. Open index.html in your browser to view the portfolio locally.
3. To host on GitHub Pages, create a repo and push these files to the main branch.
